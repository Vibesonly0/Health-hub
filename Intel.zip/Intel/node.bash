npm init -y
npm install express mysql2 body-parser cors bcrypt jsonwebtoken