-- Create database
CREATE DATABASE healthhub;
USE healthhub;

-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Health data table
CREATE TABLE health_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    blood_pressure VARCHAR(10),
    heart_rate INT,
    blood_sugar INT,
    weight DECIMAL(5,2),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Exercise data table
CREATE TABLE exercise_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    exercise_type ENUM('cardio', 'strength', 'flexibility') NOT NULL,
    exercise_name VARCHAR(100) NOT NULL,
    duration INT NOT NULL,
    calories INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Nutrition data table
CREATE TABLE nutrition_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    meal_type ENUM('breakfast', 'lunch', 'dinner', 'snack') NOT NULL,
    meal_name VARCHAR(100) NOT NULL,
    calories INT NOT NULL,
    carbs INT NOT NULL,
    protein INT NOT NULL,
    fat INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Reminders table
CREATE TABLE reminders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(100) NOT NULL,
    time TIME NOT NULL,
    date DATE NOT NULL,
    repeat ENUM('none', 'daily', 'weekly', 'monthly') DEFAULT 'none',
    category ENUM('general', 'medication', 'exercise', 'meal', 'water') DEFAULT 'general',
    completed BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (user_id) REFERENCES users(id)
);